from setuptools import setup

setup(
    name='python_programming',
    version='',
    packages=['lesson_package', 'lesson_package.talk', 'lesson_package.tools'],
    url='',
    license='',
    author='daisaku.okada',
    author_email='',
    description=''
)
