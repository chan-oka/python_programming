from lesson_package.tools import utils

def sing():
    return 'ihububbyb'

def cry():
    return utils.say_twice('mojibutvtvt')